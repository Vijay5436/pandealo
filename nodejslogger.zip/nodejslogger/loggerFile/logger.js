const {
  createLogger,
  format,
  transports,
} = require('winston');

const logger = createLogger({
  transports: [
    new transports.File({
      filename: 'file.log',
      level: 'info',
      format: format.combine(format.timestamp(), format.simple()),
    }),
    new transports.Console(),
  ],
});
module.exports = logger;
